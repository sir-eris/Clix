# /usr/local/.clix/project_token/urls.py

import sys

sys.path.insert(0, '/usr/local/.clix/CDBCB8')

# import urls
